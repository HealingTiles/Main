import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export default function HealingTilesHome() {
  return (
    <div className="min-h-screen bg-blue-50 text-gray-900 p-6 md:p-12 space-y-8">
      <header className="space-y-2">
        <h1 className="text-4xl font-bold text-blue-800">Healing Tiles</h1>
        <p className="text-lg max-w-xl">
          Soul readings, rune messages, and sacred writings for the journey of remembrance. 
          Crafted by Nicole — healer, scribe, and keeper of memory.
        </p>
        <p className="text-md italic">
          Not on social media often — best way to reach me: <a href="mailto:nicfoster2024@gmail.com" className="underline">nicfoster2024@gmail.com</a>
        </p>
      </header>

      <section className="grid md:grid-cols-2 gap-6">
        <Card>
          <CardContent className="p-4">
            <h2 className="text-xl font-semibold">🜄 SoulRune Reading (Live)</h2>
            <p className="mt-2">30–45 min Zoom session | 3–5 rune spread + post-session message</p>
            <p className="mt-1">Suggested exchange: $88 (Pay-what-you-can available)</p>
            <Button className="mt-3" asChild>
              <a href="mailto:nicfoster2024@gmail.com?subject=SoulRune Reading Request">Book via Email</a>
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <h2 className="text-xl font-semibold">🜁 Channeled Rune Writing</h2>
            <p className="mt-2">Receive a poetic, personal rune reading via email (PDF format)</p>
            <p className="mt-1">Suggested exchange: $55 (Pay-what-you-can available)</p>
            <Button className="mt-3" asChild>
              <a href="mailto:nicfoster2024@gmail.com?subject=Channeled Rune Writing Request">Request Reading</a>
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <h2 className="text-xl font-semibold">🜂 Rune + Ritual Combo</h2>
            <p className="mt-2">Full rune spread, past life channeling + custom ritual for transformation</p>
            <p className="mt-1">Suggested exchange: $111 (Pay-what-you-can available)</p>
            <Button className="mt-3" asChild>
              <a href="mailto:nicfoster2024@gmail.com?subject=Rune + Ritual Combo Request">Book This Offering</a>
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <h2 className="text-xl font-semibold">🜃 Custom Soul Writing</h2>
            <p className="mt-2">Personal message or myth channeled just for you — no question needed</p>
            <p className="mt-1">Suggested exchange: $44–$88 (Pay-what-you-can available)</p>
            <Button className="mt-3" asChild>
              <a href="mailto:nicfoster2024@gmail.com?subject=Custom Soul Writing Request">Request Writing</a>
            </Button>
          </CardContent>
        </Card>
      </section>

      <footer className="pt-12 text-sm text-gray-600">
        <p>
          Send your contribution with love and gratitude to: <a href="https://paypal.me/HealingTiles" className="underline">paypal.me/HealingTiles</a>
        </p>
        <p className="mt-2">
          Thank you for visiting Healing Tiles — where memory, light, and soul converge.
        </p>
      </footer>
    </div>
  );
}