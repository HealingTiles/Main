# Healing Tiles

A soul-rooted spiritual service website for Nicole's intuitive offerings — rune readings, ritual writing, and energy guidance.

## To Deploy:

1. Upload this folder to a GitHub repo.
2. Go to Netlify and choose "New Site from Git".
3. Select the repo and deploy.
4. Your site will go live automatically.

Booking Email: nicfoster2024@gmail.com  
Payment: https://paypal.me/HealingTiles